﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ControlGastosWeb.Migrations
{
    public partial class AgregarCamposSQLDirecto : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
                IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Gastos') AND name = 'NombreComercio')
                BEGIN
                    ALTER TABLE Gastos ADD NombreComercio NVARCHAR(100) NOT NULL DEFAULT 'Sin especificar'
                END
            ");

            migrationBuilder.Sql(@"
                IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Gastos') AND name = 'TipoDocumento')
                BEGIN
                    ALTER TABLE Gastos ADD TipoDocumento INT NOT NULL DEFAULT 1
                END
            ");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Gastos') AND name = 'NombreComercio') ALTER TABLE Gastos DROP COLUMN NombreComercio");
            migrationBuilder.Sql("IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Gastos') AND name = 'TipoDocumento') ALTER TABLE Gastos DROP COLUMN TipoDocumento");
        }
    }
}