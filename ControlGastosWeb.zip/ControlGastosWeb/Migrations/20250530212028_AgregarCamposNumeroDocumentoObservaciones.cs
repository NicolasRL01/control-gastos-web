﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ControlGastosWeb.Migrations
{
    /// <inheritdoc />
    public partial class AgregarCamposNumeroDocumentoObservaciones : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "TipoDocumento",
                table: "Gastos",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddColumn<string>(
                name: "NumeroDocumento",
                table: "Gastos",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Observaciones",
                table: "Gastos",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "NumeroDocumento",
                table: "Gastos");

            migrationBuilder.DropColumn(
                name: "Observaciones",
                table: "Gastos");

            migrationBuilder.AlterColumn<int>(
                name: "TipoDocumento",
                table: "Gastos",
                type: "int",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");
        }
    }
}
